<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Edição de Contas a Receber - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/listagens.css"/>
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Processos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/incluiProcesso.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/listagemProcesso.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/pesquisaProcesso.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/editaProcesso.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/excluiProcesso.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>

		<br><br>
	
		<?php
				//recebe cada campo do formulário e o coloca em uma variável
				$nome = $_POST["contaReceber"];
				$data = $_POST["dataReceber"];
					$dataPgto = implode("-", array_reverse(explode("/", $data)));
				$valor = $_POST["valorReceber"];
				$situa = $_POST["situacaoReceber"];
				$login = "";
					
				//verificando campos
				$camposOK = true;
					
				if($nome == ""){
					echo "<b>Informe NOME DO DEVEDOR!</b><br>";
					$camposOK = false;
				}
				if($data == ""){
					echo "<b>Informe DATA DE PAGAMENTO!</b><br>";
					$camposOK = false;
				}
				if($valor == ""){
					echo "<b>Informe VALOR DO CRÉDITO!</b><br>";
					$camposOK = false;
				}
				if($situa == ""){
				echo "<b>Informe SITUAÇÃO DO PAGAMENTO!</b><br>";
				$camposOK = false;
			}
				
				//incluindo os dados no DB
				if($camposOK){
					
					include("../conexaoBD.php");
						
					$grava = mysqli_query($conexao, "UPDATE contasreceber SET contaReceber='$nome', dataReceber='$dataPgto', valorReceber='$valor',
										situacaoReceber='$situa', advogado_oab='$login'");

					//verificando erro na gravação dos dados
					if(!$grava)
						echo "<script> alert ('ERRO NA GRAVAÇÃO DOS DADOS!!!')</script>" .mysqli_error($conexao);
					else
						echo "<br><br><br><center><font face='Constantia' size='5'><b>CONTA ATUALIZADA COM SUCESSO!</b></font></center>";
				}
		?>
		<br><br><br>
		<center><form action="atualizaContaReceber.php">
				<input type="submit" name="btNovo" value="Nova Atualização? Clique Aqui"/>
		</form></center>
	</body>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<div align="left"><font face="verdana" size="3">Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address></font>
	</div>
</html>