<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Atualização de Contas a Pagar - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/listagens.css"/>
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Processos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/incluiProcesso.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/listagemProcesso.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/pesquisaProcesso.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/editaProcesso.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/excluiProcesso.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>
						
		<br><br><br>

		<h1>Pesquisa - Atualização de Contas a Pagar</h1>
		<center><form action="atualizaContaPagar.php" method="POST">
		<th><b>Informe o NOME DO CREDOR:</b></th>
		<input type="text" name="credor" size="40" maxlength="40"/>
		<input type="submit" name="btnPesquisa" value="Pesquisar Conta"/>
		</form></center>

			<?php

				if(isset($_POST["credor"])){
					$nome = $_POST["credor"];
					
					include("../conexaoBD.php");
					
					$busca = mysqli_query($conexao, "SELECT contaPagar, dataPagar, valorPagar, situacaoPagar FROM contaspagar WHERE contaPagar = '$nome'");
					$query = mysqli_num_rows($busca);
					
					if($query == 1){
					
						echo "<br><br><center><font face='Constantia' size='5'><b><u>Resultado da Pesquisa:</b></u></font></center><br>";
						echo "<center><table border=2>";
						echo "<tr>
								<th>Nome Credor:</th>
								<th>Data Pagar:</th>
								<th>Valor (em R$):</th>
								<th>Situação:</th>
								<th>Clique botão para:</th>
							</tr></center>";
						
						$result = mysqli_query($conexao, "SELECT contaPagar, dataPagar, valorPagar, situacaoPagar FROM contaspagar WHERE contaPagar = '$nome'") or die ("ERRO AO PESQUISAR DADOS!" .mysqli_error($conexao));
						
						while($registro = mysqli_fetch_assoc($result)){
							
							$data = date("d/m/Y", strtotime($registro['dataPagar']));
							
							echo "<tr>
									<td>".$registro['contaPagar']."</td>
									<td>".$data."</td>
									<td>".$registro['valorPagar']."</td>
									<td>".$registro['situacaoPagar']."</td>
									<td><a href='linkAtualizaContaPagar.php?nome=".$registro['contaPagar']."'><img src='../imagens/editar.png'></a></td>
								</tr>";
						}
						echo "</table>";
					}
					if($query == 0){
						echo "<script> alert ('CREDOR NÃO CONSTA EM NOSSO BANCO DE DADOS!!!'); refresh(); history.go(-1);</script>";
					}
				}
			?>
	</body>
	<br><br>
	<br><br>
	<div align="left"><font face="verdana" size="3">Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address></font>
	</div>
</html>