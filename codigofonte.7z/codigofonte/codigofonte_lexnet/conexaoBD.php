<?php
// Conex�o com o banco de dados
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "lexnet";

$conexao = mysqli_connect($servidor, $usuario, $senha, $dbname) or die("Nao foi possivel conectar ao Banco de Dados!" . mysql_error());

// Alterar o charset para evitar problemas de acentua��o com o banco de dados
mysqli_set_charset($conexao, 'utf8');
?>