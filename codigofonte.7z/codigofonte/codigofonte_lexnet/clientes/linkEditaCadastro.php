<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Atualização de Cadastro - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Processos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/incluiProcesso.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/listagemProcesso.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/pesquisaProcesso.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/editaProcesso.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/excluiProcesso.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>
			
			<?php
				if(isset($_GET["cpf"])){
					$cpf = $_GET["cpf"];
					
					echo "<script> alert ('DESEJA REALMENTE ATUALIZAR ESTE CADASTRO?');</script>";
					include("../conexaoBD.php");
					
					$sql = "SELECT * FROM cadastroscliente WHERE cpf = '$cpf'";
					$result = mysqli_query($conexao, $sql) or die ("ERRO AO PESQUISAR DADOS!" .mysqli_error($conexao));
					
					if($registro = mysqli_fetch_assoc($result)){
						$nome = $registro["nome"];
						$natural = $registro["naturalidade"];
						$dtNasc = $registro["nascimento"];
						$nome_Pai = $registro["nomePai"];
						$nome_Mae = $registro["nomeMae"];
						$sexo = $registro["sexo"];
						$cpf = $registro["cpf"];
						$rg = $registro["rg"];
						$estado_Civil = $registro["estadoCivil"];
						$filhos = $registro["filhos"];
						$ender = $registro["endereco"];
						$bairro = $registro["bairro"];
						$cidade = $registro["cidade"];
						$cep = $registro["cep"];
						$estado = $registro["estado"];
						$fone = $registro["foneFixo"];
						$celular = $registro["foneCelular"];
						$email = $registro["email"];
						$area_produto = $registro["areaAtendecrime"];
						$area_serviço = $registro["areaAtendeserviço"];
						
						$data_nasc = date("d/m/Y", strtotime($dtNasc));
					}
				}
			?>
			<script type="text/javascript" src="../scriptsJQuery/jquery.js"></script>
			<script type="text/javascript" src="../scriptsJQuery/jquery.maskedinput.js"></script>
			<script type="text/javascript"> //função máscara
				jQuery.noConflict();
				jQuery(function($){
					$("#dataNasc").mask("99/99/9999");
					$("#cpf").mask("999.999.999-99");
					$("#cep").mask("99.999-999");
					$("#fone").mask("(99) 9999-9999");
					$("#celular").mask("(99) 99999-9999");
					});
			</script>
				<br><br>
				<h1>Edição de Cadastro</h1>
				<center><font type="Constantia" size="4"><b>(Altere somente os campos necessários)</b></font></center>
				<form name="formEditaCad" method="POST" action="salvaEdicaoCadastro.php">
				<br>
				<table>
					<tr>
						<th>Nome:</th>
						<td><input type="text" name="nome" size="50" maxlength="50" value="<?php echo $nome ?>"/></td>
					</tr>
					<tr>
					<th>Naturalidade:</th>
						<td><input type="text" name="natural" size="40" maxlength="40" value="<?php echo $natural ?>"/></td>
					</tr>
					<tr>
						<th>Data de Nascimento:</th>
						<td><input type="text" name="dtNasc" id="dataNasc" value="<?php echo $data_nasc ?>"/></td>
					</tr>
					<tr>
						<th>Filiação:</th>
						<td>Nome do Pai:<input type="text" name="nomePai" size="50" maxlength="50" value="<?php echo $nome_Pai ?>"/><br>
						Nome da Mãe:<input type="text" name="nomeMae" size="50" maxlength="50" value="<?php echo $nome_Mae ?>"/></td>
					</tr>
					<tr>
						<th>Sexo:</th>
						<td><?php
								if($sexo == "Masculino"){
										echo "<input type='radio' name='sexo' value='Masculino' checked>Masculino<br>";
										echo "<input type='radio' name='sexo' value='Feminino'/>Feminino<br>";
								}
								else if($sexo =="Feminino"){
										echo "<input type='radio' name='sexo' value='Masculino'>Masculino<br>";
										echo "<input type='radio' name='sexo' value='Feminino' checked/>Feminino<br>";
								}
							?>
						</td>
					</tr>
					<tr>
						<th>CPF:</th>
						<td><input type="hidden" name="CPF" id="cpf" value="<?php echo $cpf ?>"/></td>
					</tr>
					<tr>
						<th>Identidade(RG):</th>
						<td><input type="text" name="RG" size="15" maxlength="15" value="<?php echo $rg ?>"/></td>
					</tr>
					<tr>
						<th>Estado Civil:</th>
						<td><select name="estadocivil">
							<option value="<?php echo $estado_Civil; ?>"><?php echo $estado_Civil; ?></option>
							<option value="Casado/a">Casado/a</option>
							<option value="Solteiro/a">Solteiro/a</option>
							<option value="Divorciado/a">Divorciado/a</option>
							<option value="Viuvo/a">Viúvo/a</option>
							<option value="Concunbino/a">Concunbino/a</option>
							</select></td>
					</tr>
					<tr>
						<th>Filhos?<br><font type="Constancia" size="2">(se não possuir, preencha com "zeros")</font></th>
						<td><input name="filhos" type="text" size="2" maxlength="2" value="<?php echo $filhos ?>"/></td>
					</tr>
					<tr>
						<th>Endereço:</th>
						<td><textarea name="endereco" cols="30" rows="3"><?php echo $ender ?></textarea>
						</td>
					</tr>
					<tr>
						<th>Bairro:</th>
						<td><input type="text" name="bairro" size="30" maxlength="40" value="<?php echo $bairro ?>"/></td>
					</tr>
					<tr>
						<th>Cidade:</th>
						<td><input type="text" name="cidade" size="30" maxlength="40" value="<?php echo $cidade ?>"/></td>
					</tr>
					<tr>
						<th>CEP:</th>
						<td><input type="text" name="cep" id="cep" value="<?php echo $cep ?>"/></td>
					</tr>
					<tr>
						<th>Estado:</th>
						<td><select name="listaestados">
							<option value="<?php echo $estado; ?>"><?php echo $estado; ?></option>
							<option value="AC">AC</option>
							<option value="AL">AL</option>
							<option value="AP">AP</option>
							<option value="AM">AM</option>
							<option value="BA">BA</option>
							<option value="CE">CE</option>
							<option value="ES">ES</option>
							<option value="DF">DF</option>
							<option value="GO">GO</option>
							<option value="MA">MA</option>
							<option value="MT">MT</option>
							<option value="MS">MS</option>
							<option value="MG">MG</option>
							<option value="PA">PA</option>
							<option value="PB">PB</option>
							<option value="PR">PR</option>
							<option value="PE">PE</option>
							<option value="PI">PI</option>
							<option value="RJ">RJ</option>
							<option value="RN">RN</option>
							<option value="RS">RS</option>
							<option value="RO">RO</option>
							<option value="RR">RR</option>
							<option value="SC">SC</option>
							<option value="SP">SP</option>
							<option value="SE">SE</option>
							<option value="TO">TO</option>
							</select></td>
					</tr>
					<tr>
						<th>Telefone fixo com DDD:<br><font type="Constancia" size="2">(se não possuir, preencha com "zeros")</font></th>
						<td><input type="text" name="fone" id="fone" value="<?php echo $fone ?>"/></td>
					</tr>
					<tr>
						<th>Telefone celular com DDD:<br><font type="Constancia" size="2">(se não possuir, preencha com "zeros")</font></th>
						<td><input type="text" name="celular" id="celular" value="<?php echo $celular ?>"/></td>
					</tr>
					<tr>
						<th>E-mail:</th>
						<td><input type="text" name="mail" size="50" maxlength="50"  value="<?php echo $email ?>"/></td>
					</tr>
					<tr>
						<th>Área de Atendimento:</th>
						<td>
						<?php
							if($Produto== "Sim")
								echo "<input type='checkbox' name='produto' value='Sim' checked/>produto<br>";
								else echo "<input type='checkbox' name='produto' value='Sim'/>produto<br>";
							
							if($Serviço == "Sim")
								echo "<input type='checkbox' name='serviço' value='Sim' checked/>serviço<br></td>";
								else echo "<input type='checkbox' name='serviço' value='Sim'/>produto<br></td>";
							
						?>
					</tr>
				</table>
				<br><br>
				<center><input type="submit" name="btSalvar" value="Salvar Atualização"/></center>
			</form>
			
	</body>
	<br><br>
	<br><br>
	<div align="left"><font face="verdana" size="3">Desenvolvedores CC7:<br>
	<address><b>Anhanguera<br></b>Ciencia da computação/turma 2014</address></font>
	</div>
</html>