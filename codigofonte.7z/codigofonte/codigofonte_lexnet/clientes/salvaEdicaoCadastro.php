<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Atualização de Cadastro - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"></center>
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/listagens.css"/>
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu">
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix">
						<li><a href="incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix">
						<li><a href="excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu">
				<li><a href="">Cadastro Processos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/incluiProcesso.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/listagemProcesso.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/pesquisaProcesso.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/editaProcesso.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/excluiProcesso.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu">
				<li><a href="">Controle Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>

		<?php
			//recebe cada campo do formulário e o coloca em uma variável
			$nome = $_POST["nome"];
			$natural = $_POST["natural"];
			$nasc = $_POST["dtNasc"];
				$data_nasc = implode("-", array_reverse(explode("/", $nasc)));
			$pai = $_POST["nomePai"];
			$mae = $_POST["nomeMae"];
			$sex = $_POST["sexo"];
			$cpf = $_POST["CPF"];
			$rg = $_POST["RG"];
			$estado_Civil = $_POST["estadocivil"];
			$filhos = $_POST["filhos"];
			$ender = $_POST["endereco"];
			$bairro = $_POST["bairro"];
			$cidade = $_POST["cidade"];
			$cep = $_POST["cep"];
			$estado = $_POST["listaestados"];
			$fone = $_POST["fone"];
			$celular = $_POST["celular"];
			$email = $_POST["mail"];
			$area_criminal = isset($_POST["criminal"]) ? $_POST["criminal"]: '';
			$area_civel = isset($_POST["civel"]) ? $_POST["civel"]: '';
			$resp_Cadastro = $_POST["respCad"];
			$situa = $_POST["situacao"];
			$login = "";
				
			//verificando campos
			$camposOK = true;
				
			if($nome == ""){
				echo "<b>Informe o NOME!</b><br>";
				$camposOK = false;
			}
			if($natural == ""){
				echo "<b>Informe a NATURALIDADE!</b><br>";
				$camposOK = false;
			}
			if($nasc == ""){
				echo "<b>Informe DATA DE NASCIMENTO!</b><br>";
				$camposOK = false;
			}
			if($pai == ""){
				echo "<b>Informe o NOME DO PAI!</b><br>";
				$camposOK = false;
			}
			if($mae == ""){
				echo "<b>Informe o NOME DA MÃE!</b><br>";
				$camposOK = false;
			}
			if($sex == ""){
				echo "<b>Informe o SEXO!</b><br>";
				$camposOK = false;
			}
			if($cpf == ""){
				echo "<b>CPF INVÁLIDO!</b><br>";
				$camposOK = false;
			}
			if($rg == ""){
				echo "<b>Informe o RG!</b><br>";
				$camposOK = false;
			}
			if($estado_Civil == ""){
				echo "<b>Informe o ESTADO CIVIL!</b><br>";
				$camposOK = false;
			}
			if($filhos == ""){
				echo "<b>Informe SE POSSUI FILHOS!</b><br>";
				$camposOK = false;
			}
			if($ender == ""){
				echo "<b>Informe o ENDEREÇO!</b><br>";
				$camposOK = false;
			}
			if($bairro == ""){
				echo "<b>Informe o BAIRRO!</b><br>";
				$camposOK = false;
			}
			if($cidade == ""){
				echo "<b>Informe a CIDADE!</bt><br>";
				$camposOK = false;
			}
			if($cep == ""){
				echo "<b>Informe o CEP!</bt><br>";
				$camposOK = false;
			}
			if($estado == ""){
				echo "<b>Informe o ESTADO!</b><br>";
				$camposOK = false;
			}
			if($fone == ""){
				echo "<b>Informe o TELEFONE COM DDD!</b><br>";
				$camposOK = false;
			}
			if($celular == ""){
				echo "<b>Informe o CELULAR COM DDD!</b><br>";
				$camposOK = false;
			}
			if($email == "" || $email == "email@cliente"){
				echo "<b>Informe o E-MAIL!</b><br>";
				$camposOK = false;
			}
			if($resp_Cadastro == ""){
				echo "<b>Informe o RESPONSÁVEL PELO CADASTRO!</b><br>";
				$camposOK = false;
			}
			if($situa == ""){
				echo "<b>Informe a SITUAÇÃO CONTRATUAL!</b><br>";
				$camposOK = false;
			}
			
			//convertendo variáveis tipo "checkbox" para string
			if(empty($area_criminal)) $area_criminal = "Não";
			if(empty($area_civel)) $area_civel = "Não";
				
			echo "<br><br><br>";
			
			if($camposOK){
				include("../conexaoBD.php");
				
				$sql = "UPDATE cadastroscliente SET nome='$nome', naturalidade='$natural', nascimento='$data_nasc', nomePai='$pai', nomeMae='$mae', sexo='$sex',
				cpf='$cpf', rg='$rg', estadoCivil='$estado_Civil', filhos='$filhos', endereco='$ender', bairro='$bairro', cep='$cep', cidade='$cidade', estado='$estado',
				foneFixo='$fone', foneCelular='$celular', email='$email', areaAtendecrime='$area_criminal', areaAtendecivel='$area_civel', respCadastro='$resp_Cadastro', situacao='$situa', advogado_oab='$login' WHERE cpf='$cpf'";
				
				$result_usuario = mysqli_query($conexao, $sql);
				
				if(!$result_usuario){
					echo "<p><center><font face='Constantia' size='5'/><b>ERRO AO ATUALIZAR CADASTRO!</center></font></b>" .mysqli_error($conexao);
				}
					else{
						echo "<p><center><font face='Constantia' size='5'/><b>CADASTRO ATUALIZADO COM SUCESSO!</center></font></b>";
					}
			}
			?>
			<br><br><br>
			<center><form action="listagemCadastro.php">
				<input type="submit" name="btNovo" value="Nova Atualização? Clique Aqui"/>
			</form></center>
	</body>
	<br><br>
	<br><br>
	<div align="left"><font face="verdana" size="3">Desenvolvedores CC7:<br>
	<address><b>Anhanguera<br></b>Ciencia da computação/turma 2014</address></font>
	</div>
</html>