<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Exclusão de Cadastro - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix">
						<li><a href="incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix">
						<li><a href="excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Processos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/incluiProcesso.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/listagemProcesso.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/pesquisaProcesso.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/editaProcesso.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/excluiProcesso.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>
			
		<br><br><br>
			
			<?php
				if(isset($_GET['cpf'])){
					$codigo = $_GET['cpf'];
				}
				echo "<script> alert ('DESEJA REALMENTE EXCLUIR ESTE CADASTRO?');</script>";
				
				include("../conexaoBD.php");
				
				$sql = "DELETE FROM cadastroscliente WHERE cpf = '$codigo'";
				$result = mysqli_query($conexao, $sql) or die ("ERRO AO PESQUISAR DADOS!".mysqli_error($conexao));
				
				if(!$sql){
					echo "<br><br><center><font face='Constantia' size='5'><b>ERRO AO EXCLUIR CADASTRO!</center></font></b>".mysqli_error($conexao);
				}
					else{
						echo "<br><br><center><font face='Constantia' size='5'><b>CADASTRO EXCLUÍDO COM SUCESSO!</center></font></b>";
					}
			?>
			<br><br><br>
			<center><form action="listagemCadastro.php">
				<input type="submit" name="btNovo" value="Nova Exclusão? Clique Aqui"/>
			</form></center>
	</body>
	<br><br>
	<br><br>
	<div align="left"><font face="verdana" size="3">Desenvolvedores CC7:<br>
	<address><b>Anhanguera<br></b>Ciencia da computação/turma 2014</address></font>
	</div>
</html>