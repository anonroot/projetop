<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Exclusão de Produto - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/listagens.css"/>
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Produtos</a>
					<ul class="sub-menu clearfix">
						<li><a href="incluiProduto.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="listagemProduto.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="pesquisaProduto.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="editaProduto.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="excluiProduto.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>
			
			<script type="text/javascript" src="../scriptsJQuery/jquery.js"/></script>
			<script type="text/javascript" src="../scriptsJQuery/jquery.maskedinput.js"></script>
			<script type="text/javascript"> //função máscara
				jQuery.noConflict();
				jQuery(function($){
					$("#cpf").mask("999.999.999-99");
					});
			</script>
			
			<br><br><br>
			
			<h1>Pesquisa - Exclusão de Produto</h1><br>
			<center><form action="excluiProduto.php" method="POST">
			<th><b>Informe o CODIGO DO PRODUTO:</b></th>
			<input type="text" name="produto"/>
			<input type="submit" name="btnPesquisa" value="Pesquisar Cadastro"/>
			</form></center>

			
			<?php
				
				if(isset($_POST["Produto"])){
					$codigo = $_POST["Produto"];
					
					include("../conexaoBD.php");
					
					$busca = mysqli_query($conexao, "SELECT Produto, autor, réu, escrivania, fase, dataFase, leiArtigo FROM cadastrosProduto
											WHERE Produto = '$codigo'");
					$query = mysqli_num_rows($busca);
					
					if($query == 1){
					
						echo "<br><br><center><font face='Constantia' size='5'><b><u>Resultado da Pesquisa:</b></u></font></center><br>";
						echo "<center><table border=1>";
						echo "<tr>
								<th>Produto:</th>
								<th>Autor:</th>
								<th>Réu:</th>
								<th>Escrivania:</th>
								<th>Fase:</th>
								<th>Data Fase:</th>
								<th>Lei e Artigo:</th>
								<th>Clique botão para:</th>
							</tr></center>";
						
						$result = mysqli_query($conexao, "SELECT Produto, autor, réu, escrivania, fase, dataFase, leiArtigo FROM cadastrosProduto
											WHERE Produto = '$codigo'") or die ("ERRO AO PESQUISAR DADOS!" .mysqli_error($conexao));
						
						while($registro = mysqli_fetch_assoc($result)){
							
							$data = date("d/m/Y", strtotime($registro['dataFase']));
							
							echo "<tr>
									<td>".$registro['Produto']."</td>
									<td>".$registro['autor']."</td>
									<td>".$registro['réu']."</td>
									<td>".$registro['escrivania']."</td>
									<td>".$registro['fase']."</td>
									<td>".$data."</td>
									<td>".$registro['leiArtigo']."</td>
									<td><a href='linkExcluiProduto.php?Produto=".$registro['Produto']."'><img src='../imagens/excluir.png'></a></td>
								</tr>";
						}
					echo "</table><br><br>";
					}
					if($query == 0){
							echo "<script> alert ('Produto/Produto NÃO CONSTA EM NOSSO BANCO DE DADOS!!!'); refresh(); history.go(-1);</script>";
					}
				}
			?>
	</body>
	<br><br>
	<br><br>
	<div align="left"><font face="verdana" size="3">Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address></font>
	</div>
</html>