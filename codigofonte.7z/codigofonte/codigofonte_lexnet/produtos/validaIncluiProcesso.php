<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Inclusão de Processo - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css">
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../clientes/excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Processos</a>
					<ul class="sub-menu clearfix">
						<li><a href="incluiProcesso.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="listagemProcesso.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="pesquisaProcesso.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="editaProcesso.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="excluiProcesso.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>

		<br><br>
	
	<?php
			//recebe cada campo do formulário e o coloca em uma variável
			$protocol = $_POST['protocolo'];
			$dataP = $_POST['dtProtocolo'];
				$dataProtoc = implode("-", array_reverse(explode("/", $dataP)));
			$natureza = $_POST['natureza'];
			$autor = $_POST['autor'];
			$reu = $_POST['reu'];
			$comarca = $_POST['comarca'];
			$escriv = $_POST['escrivania'];
			$fase = $_POST['fase'];
			$dataF = $_POST['dtFase'];
				$dataFase = implode("-", array_reverse(explode("/", $dataF)));
			$juiz = $_POST['juiz'];
			$promot = $_POST['promotor'];
			$legisla = $_POST['legis'];
			$cpfAutor = $_POST['cpfAutor'];
			$login = "";
				
			//verificando campos
			$camposOK = true;
				
			if($protocol == ""){
				echo "<b> Informe o PROTOCOLO DO TRIBUNAL!</b><br>";
				$camposOK = false;
			}
			if($dataP = ""){
				echo "Informe DATA DO PROTOCOLO!<br>";
				$camposOK = false;
			}
			if($natureza == ""){
				echo "Informe a NATUREZA DA AÇÃO!<br>";
				$camposOK = false;
			}
			if($autor == ""){
				echo "Informe o AUTOR DA AÇÃO!<br>";
				$camposOK = false;
			}
			if($reu == ""){
				echo "Informe o RÉU NA AÇÃO!<br>";
				$camposOK = false;
			}
			if($comarca == ""){
				echo "Informa a COMARCA!<br>";
				$camposOK = false;
			}
			if($escriv == ""){
				echo "Informe a ESCRIVANIA DISTRIBUÍDA!<br>";
				$camposOK = false;
			}
			if($fase == ""){
				echo "Informe a FASE ATUAL!<br>";
				$camposOK = false;
			}
			if($dataF = ""){
				echo "Informe a DATA DA FASE!<br>";
				$camposOK = false;
			}
			if($juiz == ""){
				echo "Informe o JUIZ TITULAR!<br>";
				$camposOK = false;
			}
			if($promot == ""){
				echo "Informe o PROMOTOR NATURAL!<br>";
				$camposOK = false;
			}
			if($legisla == ""){
				echo "Informe ARTIGO E LEI!<br>";
				$camposOK = false;
			}
				
			//incluindo os dados no DB
			if($camposOK){
				include("../conexaoBD.php");
					
				$busca = mysqli_query($conexao, "SELECT * FROM cadastrosprocesso WHERE protocolo = '$protocol'");
				$query = mysqli_num_rows($busca);
					
					if($query == 1){
						echo "<script> alert ('PROTOCOLO JÁ CONSTA EM NOSSO BANCO DE DADOS!!!'); history.go(-1);</script>";
					}
					if($query == 0){
						$sql = mysqli_query($conexao, "INSERT INTO cadastrosprocesso (protocolo, dataProtocolo, natureza, autor, réu, comarca, escrivania, fase, 
						dataFase, juiz, promotor, leiArtigo, cliente_cpf, advogado_oab) VALUES ('$protocol', '$dataProtoc', '$natureza', '$autor', '$reu', '$comarca',
						'$escriv', '$fase', '$dataFase', '$juiz', '$promot', '$legisla', '$cpfAutor', '$login')");
					}
			}

			//verificando erro na gravação dos dados
			if(!$sql)
				echo "<script> alert ('ERRO NA GRAVAÇÃO DOS DADOS!!!');</script>" .mysqli_error($conexao);
			else
				echo "<br><br><br><center><font face='Constantia' size='6'><b>PROCESSO CADASTRADO COM SUCESSO!</b></font></center>";
	?>
	<br><br><br>
	<center><form action="incluiProcesso.html"/>
			<input type="submit" name="btNovo" value="Novo Cadastro? Clique Aqui"/>
			</form></center>
	</body>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<div align="left"><font face="verdana" size="3">Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address></font>
	</div>
</html>