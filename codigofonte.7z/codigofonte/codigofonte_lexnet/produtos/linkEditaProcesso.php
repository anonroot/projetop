<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Atualização de Processo - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
		<link rel="stylesheet" type="text/css" href="../estilos/listagens.css">
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../clientes/incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../clientes/listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../clientes/pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../clientes/editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../clientes/excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix"/>
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Processos</a>
					<ul class="sub-menu clearfix">
						<li><a href="incluiProcesso.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="listagemProcesso.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="pesquisaProcesso.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="editaProcesso.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="excluiProcesso.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>
			
			<?php
				if(isset($_GET['protocolo'])){
					$codigo = $_GET['protocolo'];	
				}
				echo "<script> alert ('DESEJA REALMENTE EDITAR ESTE PROCESSO?');</script>";
				include("../conexaoBD.php");
				
				$sql = "SELECT * FROM cadastrosprocesso WHERE protocolo = '$codigo'";
				$result = mysqli_query($conexao, $sql) or die ("ERRO AO PESQUISAR DADOS!" .mysqli_error($conexao));
				
				if($registro = mysqli_fetch_assoc($result)){
					$protocolo = $registro["protocolo"];
					$dataP = date("d/m/Y",strtotime($registro["dataProtocolo"]));
					$natureza = $registro["natureza"];
					$autor = $registro["autor"];
					$reu = $registro["réu"];
					$comarca = $registro["comarca"];
					$escrivania = $registro["escrivania"];
					$fase = $registro["fase"];
					$dataF = date("d/m/Y",strtotime($registro["dataFase"]));
					$juiz = $registro["juiz"];
					$promotor = $registro["promotor"];
					$legisla = $registro["leiArtigo"];
					$cpf_Autor = $registro["cliente_cpf"];
					$login = "";
				}
			?>
			<script type="text/javascript" src="../scriptsJQuery/jquery.js"></script>
			<script type="text/javascript" src="../scriptsJQuery/jquery.maskedinput.js"></script>
			<script type="text/javascript"> //função máscara
				jQuery.noConflict();
				jQuery(function($){
					$("#data").mask("99/99/9999");
					$("#dataF").mask("99/99/9999");
					$("#cpfAutor").mask("999.999.999-99");
					});
			</script>
				<br><br>
				<h1>Atualização de Processos</h1>
				<center><font type="Constantia" size="4"><b>(Altere somente os campos necessários)</b></font></center>
				<form name="formEditaProc" method="POST" action="salvaEdicaoProcesso.php">
				<br>
				<table>
					<tr>
						<th>Protocolo do Tribunal:</th>
						<td><input type="hydden" name="protocolo" size="20" maxlength="20" value="<?php echo $protocolo; ?>"/></td>
					</tr>
					<tr>
					<th>Data do Protocolo:</th>
						<td><input type="text" name="dtProtocolo" id="data" value="<?php echo $dataP; ?>"/></td>
					</tr>
					<tr>
						<th>Natureza:</th>
						<td><input type="text" name="natureza" size="50" maxlength="50" value="<?php echo $natureza; ?>"/></td>
					</tr>
					<tr>
						<th>Autor:</th>
						<td><input type="text" name="autor" size="50" maxlength="50" value="<?php echo $autor; ?>"/></td>
					</tr>
					<tr>
						<th>Réu:</th>
						<td><input type="text" name="reu" size="50" maxlength="50" value="<?php echo $reu; ?>"/></td>
					</tr>
					<tr>
						<th>Comarca:</th>
						<td><input type="text" name="comarca" size="50" maxlength="50" value="<?php echo $comarca; ?>"/></td>
					</tr>
					<tr>
						<th>Escrivania:</th>
						<td><input name="escrivania" size="50" maxlength="50" value="<?php echo $escrivania; ?>"/></td>
					</tr>
					<tr>
						<th>Fase:</th>
						<td><input type="text" name="fase" size="50" maxlength="50" value="<?php echo $fase; ?>"/></td>
					</tr>
					<tr>
						<th>Data Fase:</th>
						<td><input type="text" name="dtFase" id="dataF" value="<?php echo $dataF; ?>"/></td>
					</tr>
					<tr>
						<th>Juiz:</th>
						<td><input type="text" name="juiz" size="50" maxlength="50" value="<?php echo $juiz; ?>"/></td>
					</tr>
					<tr>
						<th>Promotor:</th>
						<td><input type="text" name="promotor" size="50" maxlength="50" value="<?php echo $promotor; ?>"/></td>
					</tr>
					<tr>
						<th>Lei e Artigo:</th>
						<td><input type="text" name="legis" size="50" maxlength="50" value="<?php echo $legisla; ?>"/></td>
					</tr>
					<tr>
					<th>CPF do Autor*:<br><font type="constancia" size="3">(Campo não obrigatório)*</th>
					<td><input type="text" name="cpfAutor" id="cpfAutor" value="<?php echo $cpf_Autor; ?>"/></td>
				</tr>
				</table>
				<center><input type="submit" name="btSalvar" value="Salvar Atualização"/></center>
			</form>
	</body>
	<br><br>
	<br><br>
	<div align="left"><font face="verdana" size="3">Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address></font>
	</div>
</html>