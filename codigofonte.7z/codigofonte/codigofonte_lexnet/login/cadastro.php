<html>
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8"/>
    <head>
	<title>Cadastro de Advogados - LEXNet</title>
	<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
	<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
	<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
	<script language="Javascript">
			function validacao (){
		if(document.form.nome.value==""){
			alert("Preencha o campo nome");
			document.form.nome.focus();
			return false;
		}
		if(document.form.OAB.value==""){
			alert("Preencha o campo OAB");
			document.form.OAB.focus();
			return false;
		}
		if(document.form.listaestados.value==""){
			alert("Selecione Estado");
			document.form.listaestados.focus();
			return false;
		}	
		if(document.form.maillogin.value=="" || document.form.maillogin.value.indexOf('@')==-1 || document.form.maillogin.value.indexOf('.')==-1){
			alert("É necessário um E-mail para login");
			document.form.maillogin.focus();
			return false;
		}
		if(document.form.senha.value.length < 5){
			alert("Senha menor que 5 caracteres!");
			document.form.senha.focus();
			return false;
		}
		if(document.form.confirmasenha.value.length < 5){
			alert("Confirmação de senha menor que 5 caracteres!");
			document.form.confirmasenha.focus();
			return false;
		}
	}
	</script>
	<script type="text/javascript" src="../scriptsJQuery/jquery.js"/></script>
	<script type="text/javascript" src="../scriptsJQuery/jquery.maskedinput.js"></script>
	<script type="text/javascript"> //função máscara
		jQuery.noConflict();
		jQuery(function($){
			$("#fone").mask("(99) 9999-9999");
			$("#celular").mask("(99) 99999-9999");
			});
	</script>
    </head>
    <body>
		<div class="cabecalho">
			<div class="menu-container">
				<ul class="menu">
					<li><a href="">Login no Sistema</a>
						<ul class="sub-menu clearfix">
							<li><a href="logar.php">Login</a>
			</div>
			<div class="menu-container">
				<ul class="menu">
					<li><a href="">Fale Conosco</a>
						<ul class="sub-menu clearfix">
							<li><a href="../faleconosco/localiza.html">Localização e Telefones</a>
					<ul class="sub-menu clearfix">
							<li><a href="../faleconosco/faleconosco.php">Enviar Mensagem</a>
			</div>
			<div class="clock">
					<script language='javascript' src="../scriptsJQuery/clock.js"></script>
					Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
					<script language='javascript'>
						StartClock('d/m/Y', 'H:i:s');
					</script>
			</div></div>
			<br>
			<br>
			<h1>Cadastro exclusivo para Advogados - LEXNet</h1>
			<font type="verdana" size="3"><b><center>(todos os campos são de preenchimento obrigatório)</b></center></font>
			<br><br>
			<form name="form" action="retornacadastro.php" method="post" onsubmit="return validacao();">
			<table>
			<tr>
			<th>Nome completo:</th>
			<td><input type="text" name="nome" size="40" maxlength="40"/></td>
			</tr>
			<tr>
			<th>OAB:</th>
			<td><input type="text" name="OAB" size="15" maxlength="10"/></td>
			</tr>
			<tr>
			<th>Estado:</th>
			<td><select name="listaestados">
								<option>Selecione...</option>
								<option value="AC">AC</option>
								<option value="AL">AL</option>
								<option value="AP">AP</option>
								<option value="AM">AM</option>
								<option value="BA">BA</option>
								<option value="CE">CE</option>
								<option value="ES">ES</option>
								<option value="DF">DF</option>
								<option value="GO">GO</option>
								<option value="MA">MA</option>
								<option value="MT">MT</option>
								<option value="MS">MS</option>
								<option value="MG">MG</option>
								<option value="PA">PA</option>
								<option value="PB">PB</option>
								<option value="PR">PR</option>
								<option value="PE">PE</option>
								<option value="PI">PI</option>
								<option value="RJ">RJ</option>
								<option value="RN">RN</option>
								<option value="RS">RS</option>
								<option value="RO">RO</option>
								<option value="RR">RR</option>
								<option value="SC">SC</option>
								<option value="SP">SP</option>
								<option value="SE">SE</option>
								<option value="TO">TO</option>
							</select></td>
			</tr>
			<tr>
			<th>Telefone (se não possuir, preencha com "zeros"):</th>
			<td><input type="text" name="fone" id="fone"/></td>
			</tr>
			<tr>
			<th>Celular (se não possuir, preencha com "zeros"):</th>
			<td><input type="text" name="celular" id="celular"/></td>
			</tr>
			<tr>
			<th>E-mail (será usado para login de acesso ao LEXNet):</th>
			<td><input type="text" name="mail" size="40" maxlength="40" value="advogado@mail.com"/></td>
			</tr>
			<tr>
			<th>Login: (digite novamente o e-mail):</th>
			<td><input type="text" name="maillogin" size="40" maxlength="40" value="advogado@mail.com"/></td>
			</tr>
			<tr>
			<th>Senha: (minímo 5 digítos, máximo 10 digítos, será usada para acesso ao LEXNet):</th>
			<td><input type="password" name="senha" size="15" maxlength="10"/></td>
			</tr>
			<th>Confirmação de Senha (repita a senha anterior):</th>
			<td><input type="password" name="confirmasenha" size="15" maxlength="10"/></td>
			</tr>
			</table>
			<br>
			<br>
			<center><input type="submit" name="enviar" value="Cadastrar"/></center>
	</body>
	<br><br>
	<br><br>
	<font align="left" face="verdana" size="3"/>Desenvolvedores LEXNet<sup>©</sup>:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address>	
</html>