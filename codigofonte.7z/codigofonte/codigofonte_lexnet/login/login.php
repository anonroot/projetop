<html>
   <meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
   <head>
   <title>Login - LEXNet</title>
	<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
	<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
	<script type="text/javascript">
		function loginsuccessfully (){
			setTimeout("window.location='Lexnet/principal.html'",5000);
		}
		function loginfailed (){
			setTimeout("window.location='logar.html'",5000);
		}
	</script>		
   </head>
   <body>
	   <div class="cabecalho">
			<div class="menu-container">
				<ul class="menu">
					<li><a href="">Login no Sistema</a>
						<ul class="sub-menu clearfix">
							<li><a href="logar.php">Login</a>
			</div>
			<div class="menu-container">
				<ul class="menu">
					<li><a href="">Fale Conosco</a>
						<ul class="sub-menu clearfix">
							<li><a href="../localiza.html">Localização e Telefones</a>
					<ul class="sub-menu clearfix">
							<li><a href="../faleconosco/faleconosco.php">Enviar Mensagem</a>
			</div>
			<div class="clock">
					<script language='javascript' src="../scriptsJQuery/clock.js"></script>
					Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
					<script language='javascript'>
						StartClock('d/m/Y', 'H:i:s');
					</script>
			</div></div>

			<?php
				$email=$_POST["email"];
				$senha=$_POST["senha"];
				
				include("../conexaoBD.php");
					
					$sql= mysqli_query ($conexao, "SELECT * FROM advogado WHERE email='$email' and senha='$senha'");
					$result = mysqli_query($conexao, "SELECT * FROM advogado WHERE email='$email' and senha='$senha'");
					$row= mysqli_num_rows($result);
								
				if ($row>0){
					session_start();
					$_SESSION ["email"]=$_POST["email"];
					$_SESSION ["senha"]=$_POST{"senha"};
					echo "<br><br><br><center><font face='Constantia' size='5'><b>ADVOGADO LOGADO AO LEXNet!</b></font></center>";
					echo "<script>loginsuccessfully()</script>";
				}
				else {
					echo "<br><br><br><br><br><br><br><br>
					<center><font face='Constantia' size='5'><b>ADVOGADO E SENHA INVÁLIDOS OU NÃO CADASTRADOS!</b></font></center>";
					echo "<script>loginfailed()</script>";
				}
				?>
	</body>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<font align="left" face="verdana" size="3"/>Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address>
</html>