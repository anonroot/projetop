<html>
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8"/>
    <head>
       <title>Cadastro de Advogados - LEXNet</title>
	   <center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
	   <link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
	   <link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
	</head>
    <body>
	<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu">
				<li><a href="">Login no Sistema</a>
					<ul class="sub-menu clearfix">
						<li><a href="logar.html">Login</a>
		</div>
		<div class="menu-container">
			<ul class="menu">
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../localiza.html">Localização e Telefones</a>
				<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/faleconosco.php">Enviar Mensagem</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>
		
		<?php
				//recebe cada campo do formulário e o coloca em uma variável
				$nome = $_POST["nome"];
				$oab = $_POST["OAB"];
				$estado = $_POST["listaestados"];
				$fone = $_POST["fone"];
				$celular = $_POST["celular"];
				$email = $_POST["mail"];
				$login = $_POST["maillogin"];
				$senha = $_POST["senha"];
				$confirmasenha = $_POST["confirmasenha"];
					
				//verificando campos
				$camposOK = true;
					
				if($nome == ""){
					echo "<b>Informe o NOME!</b><br>";
					$camposOK = false;
				}
				if($oab == ""){
					echo "<b>Informe o numero da inscrição na OAB!</b><br>";
					$camposOK = false;
				}
				if($estado == ""){
					echo "<b>Informe o ESTADO!</b><br>";
					$camposOK = false;
				}
				if($fone == ""){
					echo "<b>Informe o TELEFONE COM DDD!</b><br>";
					$camposOK = false;
				}
				if($celular == ""){
					echo "<b>Informe o CELULAR COM DDD!</b><br>";
					$camposOK = false;
				}
				if($email == "" Or $email == "advogado@mail.com"){
					echo "<b>Informe o E-MAIL!</b><br>";
					$camposOK = false;
				}
				if($login == ""){
					echo "<b>Informe o login para acesso!</b><br>";
					$camposOK = false;
				}
				if($senha == ""){
					echo "<b>Informe uma senha!</b><br>";
					$camposOK = false;
				}
				if($senha != $confirmasenha){
					echo "<b>As SENHAS não conferem!</b><br>";
					$camposOK = false;
				}
								
				//incluindo os dados no DB
				if($camposOK){
					include("../conexaoBD.php");
						
					$busca = mysqli_query($conexao, "SELECT * FROM advogado WHERE login = '$login'");
					$query = mysqli_num_rows($busca);
						
						if($query == 1){
							echo "<script> alert ('ADVOGADO JÁ CADASTRADO!!!'); history.go(-1);</script>";						
						}
						if($query == 0){
							$sql = mysqli_query($conexao, "INSERT INTO advogado (nome, oab, estado, foneFixo, foneCelular, email, login, senha)
							VALUES ('$nome', '$oab', $estado', '$fone', '$celular', '$email','$login', '$senha')");
						}
				}
						
				//verificando erro na gravação dos dados
				if(!$sql)
					echo "<script> alert ('ERRO NA GRAVAÇÃO DOS DADOS!');</script>" .mysqli_error($conexao);
				else
					echo "<br><br><br><center><font face='Constantia' size='5'><b>CADASTRO REALIZADO COM SUCESSO! BEM-VINDO AO LEXNet!</b></font></center>";
		?>
	</body>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<font align="left" face="verdana" size="3"/>Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address>
</html>