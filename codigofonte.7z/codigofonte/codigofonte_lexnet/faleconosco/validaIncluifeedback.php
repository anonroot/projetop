<html>
	<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
	<head>
		<title>Inclusão de Feedback Fale Conosco - LEXnet</title>
		<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
		<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css">
		<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
	</head>
	<body>
		<div class="cabecalho">
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Clientes</a>
					<ul class="sub-menu clearfix">
						<li><a href="/incluiCadastro.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="listagemCadastro.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="pesquisaCadastro.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="editaCadastro.php">Atualizar</a>
					<ul class="sub-menu clearfix">
						<li><a href="excluiCadastro.php">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Cadastro Processos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/incluiProcesso.html">Incluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/listagemProcesso.php">Listar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/pesquisaProcesso.php">Pesquisar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/editaProcesso.php">Atualizar Fase</a>
					<ul class="sub-menu clearfix">
						<li><a href="../processos/##">Excluir</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Administrativo</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasPagar.html">Contas a pagar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/contasReceber.html">Contas a receber</a>
					<ul class="sub-menu clearfix">
						<li><a href="../administrativo/insumos.html">Insumos</a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="menu-container">
			<ul class="menu"/>
				<li><a href="">Fale Conosco</a>
					<ul class="sub-menu clearfix">
						<li><a href="../faleconosco/incluifeedbackfaleconosco.html">Registrar <i>Feedback</i></a>
					<ul class="sub-menu clearfix">
						<li><a href="../principal.html">Retornar</a>
					<ul class="sub-menu clearfix">
						<li><a href="../login/logout.php">Logout</a>
		</div>
		<div class="clock">
				<script language='javascript' src="../scriptsJQuery/clock.js"></script>
				Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
				<script language='javascript'>
					StartClock('d/m/Y', 'H:i:s');
				</script>
		</div></div>

		<br><br>
	
	<?php	
			$contato = $_POST["codigo"];
			$nome = $_POST["nome"];
			$celular = $_POST["fone"];
			$email = $_POST["mail"];
			$resposta = $_POST["resposta"];
			$mensagem = $_POST["mensagem"];
			
			//verificando campos
			$camposOK = true;
				
			if($contato == ""){
				echo "<b>Informe o CÓDIGO DO CONTATO!</b><br>";
				$camposOK = false;
			}
			if($nome == ""){
				echo "<b>Informe o NOME DO CONTATO!</b><br>";
				$camposOK = false;
			}
			if($celular == ""){
				echo "<b>Informe o CELULAR DO CONTATO!</b><br>";
				$camposOK = false;
			}
			if($email == ""){
				echo "<b>Informe o E-MAIL DO CONTATO!</b><br>";
				$camposOK = false;
			}
			if($resposta == ""){
				echo "<b>Inform a FORMA DE RESPOSTA!</b><br>";
				$camposOK = false;
			}
			if($mensagem == ""){
				echo "<b>Descreva a MENSAGEM RETORNADA AO CONTATO!</b><br>";
				$camposOK = false;
			}
			
			//incluindo os dados no DB
			if($camposOK){
				include("../conexaoBD.php");
					
				$busca = mysqli_query($conexao, "SELECT * FROM faleconosco WHERE id_faleconosco = '$codigo'");
				$query = mysqli_num_rows($busca);
					
					$grava = mysqli_query($conexao, "INSERT INTO faleconosco (nome, telefone, email, formaRetorno, feedback) VALUES 
					('$nome', '$celular', '$email', '$resposta', '$mensagem')");
			}

			//verificando erro na gravação dos dados
			if(!$grava)
				echo "<script> alert ('ERRO NA GRAVAÇÃO DOS DADOS!!!');</script>" .mysqli_error($conexao);
			else
				echo "<br><br><br><center><font face='Constantia' size='6'><b>CADASTRO REALIZADO COM SUCESSO!</b></font></center>";
	?>
	<br><br><br>
	<center><form action="incluiCadastro.html"/>
			<input type="submit" name="btNovo" value="Novo Cadastro? Clique Aqui"/>
			</form></center>
	</body>
	<br><br>
	<br><br>
	<font align="left" face="verdana" size="3"/>Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address>
</html>