<?
		// Coloque o email que receberá os valores
		$nome = $_POST['nome'];
		$celular = $_POST['fone']
		$email = $_POST['mail'];
		$formaRetorno = $_POST['resposta'];
		$texto = $_POST['mensagem'];
		$retorno = "";

		if($nome == "" || $celular == "" || $email == "" || $formaRetorno == "" || $texto == ""):
			?>
			<script language="JavaScript">alert('Existem campos obrigatórios não preenchidos!');
			location.href='faleconosco.php';
			</script>
			<?
		exit;
		endif;

		$pattern = "^([A-Z_a-z])+@([a-zA-Z])+";
		if(ereg($pattern,$email) == false):
			?>
			<script language="JavaScript">alert('O email não é válido');
			location.href='faleconosco.php';
			</script>
			<?
		exit;
		endif;

		$mensagem = "Mensagem enviada por: ".$nome." em: ".date("d/m/Y - H:i")."\n <br />
		Abaixo seguem os dados do usuário:\n <br />
		E-mail: ".$email."\n <br />
		A mensagem enviada a você foi a seguinte: \n <br />
		".$texto;
		$headers = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: $email <$email>\r\n";
		mail($to,$mensagem,$headers);
		
			?>
			<script language="JavaScript">alert('Sua mensagem foi enviada com êxito!');
			location.href='faleconosco.php';
			</script>
			<?
		include("../conexaoBD.php");

		$sql = mysqli_query($conexao, "INSERT INTO faleconosco (nome, telefone, email, formaRetorno, mensagem, feedback) VALUES ('$nome','$celular',
		'$email','$formaRetorno', '$texto', $retorno')");

		//verificando erro na gravação dos dados
		if(!$sql)
			echo "<script> alert ('ERRO NA GRAVAÇÃO DOS DADOS!!!');</script>" .mysqli_error($conexao);
		else
			echo "<br><br><br><center><font face='Constantia' size='5'><b>MENSAGEM ENVIADA COM SUCESSO! AGUARDE, UM ADVOGADO ENTRARÁ EM CONTATO!</b></font></center>";
?>