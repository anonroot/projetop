<html>
	<meta http-equiv="Content-Type" content="text/html" charset="utf-8"/>
	<head>
	<title>Fale Conosco - LEXNet</title>
	<center><img src="../imagens/logo.png" alt="logo" title="logo"/></center>
	<link rel="stylesheet" type="text/css" href="../estilos/paginas.css"/>
	<link rel="stylesheet" type="text/css" href="../estilos/cadastro.css"/>
	<script type="text/javascript" src="../scriptsJQuery/jquery.js"/></script>
	<script type="text/javascript" src="../scriptsJQuery/jquery.maskedinput.js"></script>
	<script type="text/javascript"> //função máscara
		jQuery.noConflict();
		jQuery(function($){
			$("#fone").mask("(99) 99999-9999");
			});
	</script>
	</head>
	<body>
		<div class="cabecalho">
			<div class="menu-container">
				<ul class="menu">
					<li><a href="">Login no Sistema</a>
						<ul class="sub-menu clearfix">
							<li><a href="../login/logar.html">Login</a>
			</div>
			<div class="menu-container">
				<ul class="menu">
					<li><a href="">Fale Conosco</a>
						<ul class="sub-menu clearfix">
							<li><a href="localiza.html">Localização e Telefones</a>
					<ul class="sub-menu clearfix">
							<li><a href="faleconosco.php">Enviar Mensagem</a>
			</div>
			<div class="clock">
					<script language='javascript' src="../scriptsJQuery/clock.js"></script>
					Hoje é dia <span id="clock_dt">Data Atual</span>, às <span id="clock_tm">Hora Atual</span>
					<script language='javascript'>
						StartClock('d/m/Y', 'H:i:s');
					</script>
			</div></div>
		<br>
		<center><h1>Fale Conosco</h1></center>
		<form name="Contato" method="post" action="recebemsg.php">
		<table align="lft">
			<tr>
				<th>Nome:</th>
					<td><input type="text" name="nome" id="nome" maxlength="70"/></td>
			</tr>
			<tr>
				<th>Nº do Celular:</th>
					<td><input type="text" name="fone" id="fone"/>
			</tr>
			<tr>
				<th>E-mail:</th>
					<td><input type="text" name="mail" id="mail" maxlength="40" value="email@mail.com"/>
			</tr>
			<tr>
				<th>Aguarda resposta por:</th>
					<td><input type="radio" name="resposta" id="resposta" value="Celular" checked/>Celular<br>
						<input type="radio" name="resposta" id="resposta" value="E-mail"/>E-mail<br>
					</td>
			</tr>
			<tr>
				<th>Mensagem: <br> (Máximo até 400 caracteres)</th>
					<td><textarea name="mensagem" cols="50" rows="10" id="mensagem" maxlength="400"></textarea>
					</td>
			</tr>
			</table>
			<br><br>
			</form>
			<center>
			<input type="submit" name="enviar" id="ok" value="Enviar mensagem" class="buttonFormContato"/>
			<input type="reset" name="limpa" id="limpa" value="Limpar dados" class="buttonFormContato"/>
			</center>
	</body>
	<br><br>
	<font align="left" face="verdana" size="3"/>Desenvolvedores LEXNet:<br>
	<address><b>José Mar de Melo e Ana Luiza Martins Ribeiro<br></b>Discentes do curso Técnico em Informática/ITEGO</address>
</html>